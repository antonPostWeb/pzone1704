<?
include 'header.php';
?>
<table id="table">
<thead>
<tr>
<th>Дата</th>
<th>Заявка</th>
<th>Текст</th>
<th>Автор</th>
</tr>
</thead>
<tbody>

<?php
$client_id = Auth::user()->id;
foreach(Message::orderBy('created_at', 'desc')->where('req_id','=', $req_id)->where('client_id','=', $client_id)->get() as $item){
echo '<tr><td>' . date("d F Y H:i", strtotime($item->created_at)) . '</td>';
$req_name =  Req::find($item->req_id);

echo '<td>' . $req_name->name . '</td>';
echo '<td>' . $item->text . '</td>';
echo '<td>';
$role = $item->role_id;
	if ($role == 1){
	echo 'Администратор';
	} elseif ($role ==2 or $role ==3){
	echo "Менеджер";
	} elseif ($role ==4) {
	echo "Клиент";
	 
	}
echo '</td>';
}




?>
</table>
<div id="formnewmessage">
<form method = "POST" action = "<?php echo URL::to('client').'/createmessage' ?>" >
<input type="hidden" name="requests" value="<?php echo $req_id; ?>" >
<textarea rows = 3 name="textnewmessage" >
</textarea>
<br>
<button type="submit">Отправить</button>

</form>
</div>

</body>
<script >

$(document).ready(function() {
$('#table').dataTable();
} );
</script>
