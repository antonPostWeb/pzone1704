<?php
include 'header.php';
?>
<div style="margin-top:5%;margin-left:25%;width:50%;height:40%;">
<div class="jumbotron">
<?php

$cur_client_id = Auth::user()->id;
echo '<div class="list-group">';
foreach (Req::where('client_id','=',$cur_client_id)->get() as $item) 
{
echo '
  <a href="'.  URL::to('client/forumcurreq/' . $item->id) .'" class="list-group-item">
    <h4><p class="text-primary"><strong>'. $item->name .'</strong></p></h4>
    <p class="text-info">'. substr($item->body,0,200) .'</p>
  </a>';
  



}
echo '</div>';


?>

</div>
</div>
