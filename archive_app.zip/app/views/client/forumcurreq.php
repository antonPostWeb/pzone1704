<?php
include 'header.php';
?>

<body>
<div class="jumbotron" style="margin:5% 15% 5% 15%;height:60%;padding:0 auto;" id="forum">
<div class="content" style = "width:90%;height:600px;margin:auto;">
   <?php 
   
$client_id = Auth::user()->id;
$have_we_one_message = Message::where('client_id','=',$client_id)->where('req_id','=',$req_id)->first();
if(isset($have_we_one_message->id)){
	foreach (Message::where('client_id','=',$client_id)->where('req_id','=',$req_id)->get() as $item){
		$role_id = $item->role_id;
 		if($role_id == 4 ){ 
			$max_id = $item->id;
			echo '<div class="panel panel-info" superattr="chat" id = "'. $item->id .'">';
			echo '<div class="panel-heading">
			<h3 class="panel-title">Клиент</h3>
			</div>
			<div class="panel-body">';
			echo '<strong>Message:</strong>'.$item->text ;
			$maybe_we_have_file = Request_attachment::where('message_id','=',$item->id)->first();
			if(isset($maybe_we_have_file)){
			echo '<br><a href = "'. Url::to('client/show/'.
			$maybe_we_have_file->id) .'"><strong>File:</strong>' . 
			$maybe_we_have_file->filename . '</a>';	
			}
			echo '</div>
			</div>';

		} elseif ($role_id == 3 or $role_id == 2){

			$max_id = $item->id;
			echo '<div class="panel panel-success" superattr="chat" id = "'. $item->id .'">';
			echo '<div class="panel-heading">
			<h3 class="panel-title">Менеджер</h3>
			</div>
			<div class="panel-body">';
			echo '<strong>Message:</strong>'.$item->text ;
			$maybe_we_have_file = Request_attachment::where('message_id','=',$item->id)->first();
			if(isset($maybe_we_have_file)){
			echo '<br><a href = "'. Url::to('client/show/'.
			$maybe_we_have_file->id) .'"><strong>File:</strong>' . 
			$maybe_we_have_file->filename . '</a>';	
			}
			echo '</div>
			</div>';


		}
	}
	 
}else {
echo '<div class="panel panel-success" superattr="chat" id = "1">';
			echo '<div class="panel-heading">
			<h3 class="panel-title">Менеджер</h3>
			</div>
			<div class="panel-body">';
			echo '<strong>Message:</strong>Вы можете начать чат';
			echo '</div>
			</div>';
}
	
	
	

	






?> 
 </div>
</div>
    
    
    <div  class="form-group" style = "margin-top:0%;margin-left:15%;" name = "newmessage">
<form method = "Post" action = "<?php echo Url::to('client/sms')?>" name = "sms" id="newmessage">
<input placeholer= "Сообщение" id="newsms" class="form-control input-sm" style="width:83.5%;" type="text" id="inputSmall" name = "sms" />
<input class = "hidden" name = "req_id" value = "<?php echo $req_id ;?>" />
<br>
<button type = "submit" class="btn btn-primary btn-xs">Отправить</button>
</form>
</div>
</body>
<script>
   $(window).load(function(){
            $(".content").mCustomScrollbar();
			$(".content").mCustomScrollbar("scrollTo","last");
        });

</script>


		