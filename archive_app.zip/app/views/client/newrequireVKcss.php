<!DOCTYPE HTML>
<html>
<head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<link rel="stylesheet" href="/css/vk.css" type="text/css" />
<link rel="stylesheet" href="/css/chosen.css" type="text/css" />

<link rel="stylesheet" href="/css/jquery.mCustomScrollbar.css" type="text/css" />

<script src = "/js/jquery.mCustomScrollbar.js"> </script>


<script src = "/js/bootstrap.js"> </script>

</head>
<style>
select[name="table_length"]{
display: none; 
}


.jumbotron {
padding:5% 5% 5% 5%;
!important;
}
td {
    
margin-left:150px;
  
}
.login_loggedout_header {
  font-weight: bold;
  font-size: 22px;
  color: #45688E;
  padding-bottom: 16px;
}
.label {
  color: #45688E;
  font-weight: bold;
  padding: 1px 0px 8px;
}
</style>
<body>
<div id="page_header" style="width: 900px;" class="p_head1 p_head_l3">
<div class="content">
<div class="back" style="width: 900px;margin-left:22%;"></div>
<div class="content">
<div id="top_nav"  class="head_nav">
    <table cellspacing="0" cellpadding="0" id="top_links">
        <tbody>
            <tr>
                <td style >
                    <nobr>
                        <a class="top_nav_link active" name="first"  id="head_people" style="margin-left:650px" href="<?php echo URL::to('client')?>" > Чат </a>
                    </nobr>
                </td>
                    <td style >
                    <nobr>
                        <a  class="top_nav_link active"  id="head_people" href="<?php echo URL::to('client').'/messages' ?>"> Файлы </a>
                    </nobr>
                </td>
                </td>
                    <td style >
                    <nobr>
                        <a class="top_nav_link active"  id="head_people" href="<?php echo URL::to('client').'/newrequire' ?>"> Help </a>
                    </nobr>
                </td>
                </td>
                    <td style >
                    <nobr>
                        <a class="top_nav_link active"  id="head_people" href="<?php echo URL::to('client').'/newrequire' ?>"> Выход </a>
                    </nobr>
                </td>
                </td>
                    <td style >
                    <nobr>
                        <a class="top_nav_link active"  id="head_people" href="<?php echo URL::to('client').'/newrequire' ?>"> Экстренный выход </a>
                    </nobr>
                </td>
            </tr>
        </tbody>
    </table>
</div>
</div>
</div>
</div>


<div id="wrap3" style="width:600px;margin-left:600px;margin-top:0px;height:500px;">
    
    
<div id="wrap2">
    
    
    
<div id="wrap1" >

<form class="form-horizontal" method = "POST" action = "<?php echo Url::to('client/newrequire')?>">
  <fieldset>
 <div class="login_loggedout_header" > Новая заявка</div>
    
      
          <div class="label">Название заявки</div>
      
        <div class="labeled"><input type="text"  placeholder="Введите название" name = "title"></div>
      
            
            <div class="label">Описание заявки</div>
      
        <div class="labeled"><textarea class="form-control" rows="3" id="textArea" placeholder = 'Введите описание' rows="5"  
	name = "body" > </textarea></div>
        
        
	
    
	 <div class="button_blue button_wide button_big" id="quick_auth_button">
    	<button type="submit" class="btn btn-primary">Отправить</button>
      </div>
 
</div>
</div>
</div>
</div>

</body>
