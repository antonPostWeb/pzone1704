<!DOCTYPE HTML>
<html>
<head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<link rel="stylesheet" href="/css/vk.css" type="text/css" />
<link rel="stylesheet" href="/css/chosen.css" type="text/css" />

<link rel="stylesheet" href="/css/jquery.mCustomScrollbar.css" type="text/css" />

<script src = "/js/jquery.mCustomScrollbar.js"> </script>


<script src = "/js/bootstrap.js"> </script>

</head>
<style>
select[name="table_length"]{
display: none; 
}


.jumbotron {
padding:5% 5% 5% 5%;
!important;
}
td {
    
margin-left:150px;
  
}
.login_loggedout_header {
  font-weight: bold;
  font-size: 22px;
  color: #45688E;
  padding-bottom: 16px;
}
.label {
  color: #45688E;
  font-weight: bold;
  padding: 1px 0px 8px;
}
h3.panel-title{
color:#2B587A;
}
div.forstyle{
    
    background:#F7F7F7;
    
}

</style>
<body>
<div id="page_header" style="width: 900px;" class="p_head1 p_head_l3">
<div class="content">
<div class="back" style="width: 900px;margin-left:22%;"></div>
<div class="content">
<div id="top_nav"  class="head_nav">
    <table cellspacing="0" cellpadding="0" id="top_links">
        <tbody>
            <tr>
                <td style >
                    <nobr>
                        <a class="top_nav_link active" name="first"  id="head_people" style="margin-left:650px" href="<?php echo URL::to('client')?>" > Чат </a>
                    </nobr>
                </td>
                    <td style >
                    <nobr>
                        <a  class="top_nav_link active"  id="head_people" href="<?php echo URL::to('client').'/messages' ?>"> Файлы </a>
                    </nobr>
                </td>
                </td>
                    <td style >
                    <nobr>
                        <a class="top_nav_link active"  id="head_people" href="<?php echo URL::to('client').'/newrequire' ?>"> Help </a>
                    </nobr>
                </td>
                </td>
                    <td style >
                    <nobr>
                        <a class="top_nav_link active"  id="head_people" href="<?php echo URL::to('client').'/newrequire' ?>"> Выход </a>
                    </nobr>
                </td>
                </td>
                    <td style >
                    <nobr>
                        <a class="top_nav_link active"  id="head_people" href="<?php echo URL::to('client').'/newrequire' ?>"> Экстренный выход </a>
                    </nobr>
                </td>
            </tr>
        </tbody>
    </table>
</div>
</div>
</div>
</div>


<div id="wrap3" style="width:600px;margin-left:600px;margin-top:0px;height:500px;">
    
    
<div id="wrap2">
   <div class="forstyle" style="width:600px;height:47px"></div>
    
    
<div id="wrap1"  class="vkmessage" style="height:500px;">
<?php
$client_id = Auth::user()->id;

$have_we_one_message = Message::where('client_id','=',$client_id)->where('req_id','=',$req_id)->first();
if(isset($have_we_one_message->id)){
	foreach (Message::where('client_id','=',$client_id)->where('req_id','=',$req_id)->get() as $item){
		$role_id = $item->role_id;
 		if($role_id == 4 ){ 
			$max_id = $item->id;
			echo '<div style="margin-left:10px;" class="panel panel-info" superattr="chat" id = "'. $item->id .'">';
			echo '<div class="panel-heading">
			<h3 class="panel-title">Клиент</h3>
			</div>
			<div class="panel-body">';
			echo $item->text ;
			$maybe_we_have_file = Request_attachment::where('message_id','=',$item->id)->first();
			if(isset($maybe_we_have_file)){
			echo '<br><a href = "'. Url::to('client/show/'.
			$maybe_we_have_file->id) .'"><strong>File:</strong>' . 
			$maybe_we_have_file->filename . '</a>';	
			}
			echo '</div>
			</div>';

		} elseif ($role_id == 3 or $role_id == 2){

			$max_id = $item->id;
			echo '<div style="margin-left:10px;" class="panel panel-success" superattr="chat" id = "'. $item->id .'">';
			echo '<div class="panel-heading">
			<h3 class="panel-title">Менеджер</h3>
			</div>
			<div class="panel-body">';
			echo $item->text ;
			$maybe_we_have_file = Request_attachment::where('message_id','=',$item->id)->first();
			if(isset($maybe_we_have_file)){
			echo '<br><a href = "'. Url::to('client/show/'.
			$maybe_we_have_file->id) .'"><strong>File:</strong>' . 
			$maybe_we_have_file->filename . '</a>';	
			}
			echo '</div>
			</div>';


		}
	}
	 
}else {
echo '<div class="panel panel-success" superattr="chat" id = "1">';
			echo '<div class="panel-heading">
			<h3 class="panel-title">Менеджер</h3>
			</div>
			<div class="panel-body">';
			echo '<strong>Message:</strong>Вы можете начать чат';
			echo '</div>
			</div>';
}
	
	
	

	





?>    
</div>
   <div class="forstyle" style="width:600px;height:94px;">
       <div  class="form-group" style = "margin-left:15%;" name = "newmessage">
           
<form method = "Post" action = "<?php echo Url::to('client/sms')?>" name = "sms" id="newmessage">
<textarea rows="3" placeholer= "Сообщение" id="newsms" class="form-control input-sm" style="width:83.5%;"  id="inputSmall" name = "sms" > </textarea>
<input class = "hidden" name = "req_id" value = "<?php echo $req_id ;?>" />
 <div class="button_blue button_wide button_big" id="quick_auth_button" style="width:150px;top:0px;float:left;">
<button type = "submit" class="btn btn-primary btn-xs">Отправить</button>

</div>
<div class="label" style="position:relative;top:-15px;right:0px;margin-left:100px;">
    <a style="margin-left:220px;margin-top:-25px;" href="#">Прикрепить</a>
    
</div>
</form>
</div>
       </div>
</div>
</div>
    


</body>
<script >



	



        $(window).load(function(){
            $(".vkmessage").mCustomScrollbar();
			$(".vkmessage").mCustomScrollbar("scrollTo","last");
        });
  
	
	
	
	

</script>
