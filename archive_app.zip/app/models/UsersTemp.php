<?php

class UsersTemp extends \Eloquent {
    
protected $table = 'users_temp';
}
