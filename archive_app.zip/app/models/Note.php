<?php

class Note extends \Eloquent {
    
protected $table = 'notes';
}
