<?php

class ClientManager extends \Eloquent {
    
protected $table = 'client_manager';
}
