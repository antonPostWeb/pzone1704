<?php

class Req extends \Eloquent {
    
protected $table = 'requests';
}
