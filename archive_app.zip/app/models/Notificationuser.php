<?php

class Notificationuser extends \Eloquent {
    
protected $table = 'notification_user';
}
