<?php

class Message extends \Eloquent {
    
protected $table = 'messages';
}
